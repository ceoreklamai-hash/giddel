module.exports=[28117,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_gurman_route_actions_0zn3rfs.js.map