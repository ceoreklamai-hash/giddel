module.exports=[51872,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_partner_analytics_route_actions_0q3m~im.js.map