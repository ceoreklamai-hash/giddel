module.exports=[2066,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_partner-requests_route_actions_0wsgxdf.js.map