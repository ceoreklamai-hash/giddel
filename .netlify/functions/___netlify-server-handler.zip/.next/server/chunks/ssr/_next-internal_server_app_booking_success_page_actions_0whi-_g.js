module.exports=[29166,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_booking_success_page_actions_0whi-_g.js.map