module.exports=[17733,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_partner-guide_page_actions_0iz18hj.js.map