module.exports=[61933,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin-guide_page_actions_0kxq7bm.js.map