module.exports=[39726,a=>{"use strict";a.s(["CATEGORY_LABELS",0,{yacht:"Яхты",wine:"Виноделие",horse:"Конные прогулки",quad:"Квадроциклы",surf:"Кайтсерфинг",fishing:"Рыбалка",rope:"Канатный парк",excursion:"Экскурсии",buggy:"Багги",jeep:"Джипинг",paraglide:"Параплан",sailing:"Парусные туры",skydive:"Скайдайвинг",kayak:"Каяки и рафтинг",diving:"Дайвинг",farm:"Гастрономия",canyon:"Хайкинг",zipline:"Зиплайн",helicopter:"Вертолётные туры",spa:"СПА и бани"}])},9041,a=>{a.v({map:"InteractiveMap-module__ZWWlNa__map"})},69783,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(39726),e=a.i(9041);let f={yacht:"#a87fe8",wine:"#c9a227",horse:"#e8a87f",quad:"#e85c5c",surf:"#5ce8d4",fishing:"#5c9ee8",diving:"#2196f3",canyon:"#6ab04c",paraglide:"#e85ce8",jeep:"#e8785c",kayak:"#5ce8a8",buggy:"#e8c05c",farm:"#b8e85c",rope:"#8c5ce8",excursion:"#e8e85c",sailing:"#5c78e8",skydive:"#ff6b6b",zipline:"#56cf6a",helicopter:"#ff9f43"};function g(a){return"data:image/svg+xml;charset=utf-8,"+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="28" height="36" viewBox="0 0 28 36">
    <path d="M14 0C6.27 0 0 6.27 0 14c0 9.33 14 22 14 22S28 23.33 28 14C28 6.27 21.73 0 14 0z" fill="${a}"/>
    <circle cx="14" cy="14" r="6" fill="white" opacity="0.9"/>
  </svg>`)}a.s(["InteractiveMap",0,function({activities:h,wines:i=[]}){let j=(0,c.useRef)(null),k=(0,c.useRef)(null);return(0,c.useEffect)(()=>{if(j.current&&!k.current)return a.A(67495).then(a=>{let b=a.map(j.current,{center:[44.8,37.8],zoom:9,zoomControl:!0});k.current=b,a.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",{attribution:"© OpenStreetMap contributors © CARTO",subdomains:"abcd",maxZoom:19}).addTo(b);let c=h.filter(a=>null!=a.lat&&null!=a.lng);c.forEach(c=>{let e=f[c.category]??"#a87fe8",h=g(e),i=a.icon({iconUrl:h,iconSize:[28,36],iconAnchor:[14,36],popupAnchor:[0,-36]}),j=a.marker([Number(c.lat),Number(c.lng)],{icon:i}),k=d.CATEGORY_LABELS[c.category]??c.category,l=c.price_from.toLocaleString("ru-RU"),m=c.duration_hours?`${c.duration_hours} ч \xb7 `:"",n=c.location_name?`<div class="lf-location">📍 ${c.location_name}</div>`:"";j.bindPopup(`
          <div class="lf-popup">
            <div class="lf-cat" style="color:${e}">${k}</div>
            <div class="lf-title">${c.title}</div>
            ${n}
            <div class="lf-meta">${m}от ${l} ₽/чел</div>
            <a href="/activities/${c.slug}" class="lf-btn">Подробнее →</a>
          </div>
        `,{maxWidth:240}),j.addTo(b)});let e=a.icon({iconUrl:g("#c9a227"),iconSize:[28,36],iconAnchor:[14,36],popupAnchor:[0,-36]});i.filter(a=>null!=a.lat&&null!=a.lng).forEach(c=>{let d=Number(c.lat),f=Number(c.lng);if(isNaN(d)||isNaN(f))return;let g=c.price_from?`от ${Number(c.price_from).toLocaleString("ru-RU")} ₽`:"";a.marker([d,f],{icon:e}).bindPopup(`
            <div class="lf-popup">
              <div class="lf-cat" style="color:#c9a227">🍷 Винодельня</div>
              <div class="lf-title">${c.name}</div>
              <div class="lf-location">📍 ${c.region}</div>
              ${g?`<div class="lf-meta">${g}</div>`:""}
              <a href="/wines/${c.slug}" class="lf-btn" style="background:#c9a227;color:#000">Подробнее →</a>
            </div>
          `,{maxWidth:240}).addTo(b)});let l=[...c.map(a=>[Number(a.lat),Number(a.lng)]),...i.filter(a=>null!=a.lat&&null!=a.lng).map(a=>[Number(a.lat),Number(a.lng)])];l.length>0&&b.fitBounds(l,{padding:[40,40],maxZoom:11})}),()=>{k.current?.remove(),k.current=null}},[h]),(0,b.jsx)("div",{ref:j,className:e.default.map})}])},67495,a=>{a.v(b=>Promise.all(["server/chunks/ssr/node_modules_leaflet_dist_leaflet-src_0t8vne..js"].map(b=>a.l(b))).then(()=>b(99661)))}];

//# sourceMappingURL=_0~qyrrn._.js.map