var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payment/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__0dyc9ag._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_payment_webhook_route_actions_0.oe6c-.js")
R.m(85396)
module.exports=R.m(85396).exports
