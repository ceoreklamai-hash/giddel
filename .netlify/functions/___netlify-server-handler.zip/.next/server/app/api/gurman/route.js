var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/gurman/route.js")
R.c("server/chunks/[root-of-the-server]__0f_0ny8._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_gurman_route_actions_0zn3rfs.js")
R.m(41718)
module.exports=R.m(41718).exports
