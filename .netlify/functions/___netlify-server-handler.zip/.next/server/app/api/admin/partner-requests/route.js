var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/partner-requests/route.js")
R.c("server/chunks/[root-of-the-server]__02yopk8._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_partner-requests_route_actions_0wsgxdf.js")
R.m(80738)
module.exports=R.m(80738).exports
