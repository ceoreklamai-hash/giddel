var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/assistant/route.js")
R.c("server/chunks/[root-of-the-server]__054tel4._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_assistant_route_actions_0.znwuh.js")
R.m(89068)
module.exports=R.m(89068).exports
