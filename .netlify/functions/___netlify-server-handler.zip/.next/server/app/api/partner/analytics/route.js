var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/partner/analytics/route.js")
R.c("server/chunks/[root-of-the-server]__0sg88y9._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_partner_analytics_route_actions_0q3m~im.js")
R.m(16622)
module.exports=R.m(16622).exports
