var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/telegram/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__0lu~ytr._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0nppfb9.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/_next-internal_server_app_api_telegram_webhook_route_actions_03~kgsl.js")
R.m(88178)
module.exports=R.m(88178).exports
