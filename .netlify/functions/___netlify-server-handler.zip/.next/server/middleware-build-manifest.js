globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/1grAzdv6PxAH5yXxrSdzS/_buildManifest.js",
    "static/1grAzdv6PxAH5yXxrSdzS/_ssgManifest.js",
    "static/1grAzdv6PxAH5yXxrSdzS/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/16fce0~0kfr7_.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/09p23sgwvk9jl.js",
    "static/chunks/turbopack-0usl689-gr446.js"
  ]
};
